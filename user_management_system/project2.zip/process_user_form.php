<?php
require('./Model.php');
require('./Users.php');

$postData = json_encode($_POST);

// for create:
$user = new Users();
$user->load($postData);
$user->save();