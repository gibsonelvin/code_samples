<?php
spl_autoload_register(function($class){
    require("./" . $class . ".php");
});

$userModel = new Users();
$getUsers = $userModel->getAll();

require('header.php');
?>


<div id='action_modal_back'></div>

<div id='action_modal'>
<h1 id='message'>Create new user:</h1>
<div onclick='Main.closeModal()' class='close_button'>x</div>
<form id='user_entry'>

    <div id='form_error'></div>

    <div class='form_label'>
        <label>First Name:</label>
    </div>
    <div class='form_field'>
        <input type='text' id='first_name' name='first_name' size=16 />
    </div>

    <div class='form_label'>
    <label>Last Name:</label>
    </div>
    <div class='form_field'>
    <input type='text' id='last_name' name='last_name' size=16 />
    </div>
    
    <div class='form_label'>
    <label>Email:</label>
    </div>
    <div class='form_field'>
    <input type='text' id='email' name='email' size=32 />
    </div>
    
    <div class='form_label'>
    <label>Mobile Number:</label>
    </div>
    <div class='form_field'>
    <input type='text' id='mobile' name='mobile' size=32 />
    </div>
    
    <div class='form_label'>
    <label>Address:</label>
    </div>
    <div class='form_field'>
    <input type='text' id='address' name='address' size=32 />
    </div>
    
    <div class='form_label'>
    <label>City:</label>
    </div>
    <div class='form_field'>
    <input type='text' id='city' name='city' size=32 />
    </div>
    
    <div class='form_label'>
    <label>State:</label>
    </div>
    <div class='form_field'>
    <input type='text' id='state' name='state' size=32 />
    </div>
    
    <div class='form_label'>
    <label>Zip:</label>
    </div>
    <div class='form_field'>
    <input type='text' id='zip' name='zip' size=32 />
    </div>
    
    <div class='form_label'>
    <label>Country:</label>
    </div>
    <div class='form_field'>
    <input type='text' id='country' name='country' size=32 />
    </div>
    
    <div class='form_label'>
    <label>Timezone:</label>
    </div>
    <div class='form_field'>
    <input type='text' id='timezone' name='timezone' size=32 />
    </div>

    <div class='form_submit'>
        <input type='button' value='Submit' onClick='Main.submitForm()' />
    </div>




</form>
</div>

<div class='body_back'>

<h3>Users <div class='new_button' onclick='Main.create()'>+</div></h3>

<center>

<table id='users_table' border=0 cellpadding=5 cellspacing=0>
    <?php

    if($getUsers->num_rows === 0) {
        echo "<h3>No records to show</h3>";
    } else {
       $i = 0;
        while($userData = $getUsers->fetch_assoc()) {

            if($i === 0) {
                echo "<tr>";
                $column_i = 0;
                foreach($userData as $field => $dataBit) {
                    $field = join(" ", array_map("ucfirst", explode("_", $field)));
                    echo "<th class='column_head column" . $column_i . "'>" . $field . "</th>";
                    $column_i++;
                }

                echo "<th>&nbsp;</th><th>&nbsp;</th></tr>";
            }

            echo "<tr>";
            
            $column_i = 0;
            foreach($userData as $dataBit) {
                echo "<td class='column" . $column_i . "'>";
                echo $dataBit;
                echo "</td>";
                $column_i++;
            }

            echo "<td class='icon' onclick='Main.edit(" . $userData['id'] . ")'>📝</td><td class='icon' onclick='Main.delete(" . $userData['id'] . ")'>🗑️</td></tr>";
            $i = 1;
        }
    }

    ?>

</table>
</center>

</div>
<div></div>



<?php
require('footer.php');
?>