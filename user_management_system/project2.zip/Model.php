<?php

Class Model {

    public $db;

    public function __construct() {
        $this->createGettersAndSetters();
    }

    protected function getGetterName($property) {
        $formattedName = $this->translateShortName($property);
        return "get" . $formattedName;
    }

    protected function getSetterName($property) {
        $formattedName = $this->translateShortName($property);
        return "set" . $formattedName;
    }

    public function createGettersAndSetters() {
        foreach($this->properties as $property => $type) {
            $getterMethodName = $this->getGetterName($property);
            $setterMethodName = $this->getSetterName($property);

            $evaluationLine = <<<END
            \$this->$getterMethodName = function() {
                return \$this->$property;
            };
END;
            eval($evaluationLine);

            $evaluationLine2 = <<<END
            \$this->$setterMethodName = function(\$value) use(\$property) {
                if(\$this->validateValue(\$property, \$value)) {
                    \$this->$property = \$value;
                } else {
                    die(json_encode('{"error": "Invalid property value (\$value) for property: \$property"}'));
                }
            };
END;
            eval($evaluationLine2);
        }
    }

    public function validateValue($property, $value) {
        echo "Validating property: $property for value $value\n\n";
        switch($this->properties[$property]) {
            case 'int':
                return (is_int($value));
                break;
            case 'string':
                return (is_string($value));
                break;
            case 'date':
                return (preg_match("/^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$/"));
                break;
            case 'email':
                return (preg_match("/^[A-Za-z0-9\.]+@[A-Za-z0-9\.]+\.[A-Za-z0-9\.]{2,3}$/", $value));
                break;
            case 'phone':
                return ($value > 2000000000 && $value < 9999999999);
                break;
            default:
                die("FATAL ERROR: Unhandled data type for property $property, and value: $value!");
        }
    }

    public function load($data) {
        foreach($data as $key => $value) {
            $setter = $this->getSetterName($key);
            // Placed in variable if needed for debugging
            $evaluationLine = "\$this->" . $setter . "(\$value);";
            eval($evaluationLine);
            echo "Setter called\n\n";
        }
    }

    public function getDB() {
        require("db.php");
        $this->db = $this->db ?? new mysqli($dbhost, $dbuser, $dbpass, $dbname) or die("Fatal error, unable to connect to DB");
    }

    public function translateShortName($shortName) {
        return join("", array_map("ucfirst", explode("_", $shortName)));
    }

    public function getAll() {
        $query = "SELECT * FROM " . $this->table_name;
        $this->getDB();
        $x_query = $this->db->query($query);
        if(!$x_query) {
            die("FATAL ERROR: Query misconfiguration: " . $this->db->error);
        }
        return $x_query;
    }

    public function save() {
        $this->getDB();
        if($this->getId()) {
            $query = "UPDATE users set";
            foreach($this->properties as $property => $type) {
                if($property === 'id') continue;
                $getter = $this->getGetterName($property);
                $query .= " $property = \"" . $this->{$getter}() . "\"";
            }
            $query .= " WHERE id=" . $this->getId();
        } else {
            $query = "INSERT INTO users VALUES(null";
            foreach($this->properties as $property => $type) {
                $getter = $this->getGetterName($property);
                $query .= ", \"" . $this->{$getter}() . "\"";
            }
            $query .= ")";
        }
        $this->db->query($query) or die(json_encode(['error' => $this->db->error]));
    }
}