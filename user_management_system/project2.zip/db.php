<?php
$dbhost = "localhost";
$dbname = "slicktext_interview";
$dbuser = "slicktext";
$dbpass = "slick";