Main = {
    create: function() {
        this.showModal();
        // alert("Creating new");
    },
    edit: function(id) {
        this.showModal();
        // alert("EDITING " + id);
    },
    submitForm: function() {
        let formObject = document.querySelector('#user_entry');
        let data = new FormData(formObject);
        this.createUser(data);
        console.log(data.entries());
    },
    delete: function(id) {
        confirmDelete = confirm("Are you sure you want to delete this record?");
        // alert("DELETING " + id);
    },
    closeModal: function() {
        document.querySelector('#action_modal').style.display = 'none';
        document.querySelector('#action_modal_back').style.display = 'none';
    },
    showModal: function() {
        document.querySelector('#action_modal').style.display = 'block';
        document.querySelector('#action_modal_back').style.display = 'block';
    },
    createUser: function(data) {
        this.xhrPost('process_user_form.php?action=create', data, function(xhr) {
            if(xhr.readyState === 4 && xhr.status === 200) {
                let response = JSON.parse(xhr.responseText);
                if(response.error) {
                    this.outputError(response.error);
                } else {
                    let usersTable = document.querySelector('#users_table');
                    let currentHTML = usersTable.innerHTML;

                    // Take passed data, and form table row to insert
                    usersTable.innerHTML = currentHTML + this.createTableRow(data);

                }
            }
        })
    },
    createTableRow: function(data) {
        let html = '<tr>';
        for(let property in data) {
            if(data.hasOwnProperty(property)) {
                html += '<td>' + data[property] + '</td>';
            }
        }
        html += '</tr>';
    },
    xhrPost: function(url, data, changeFunction) {
        let xhr = new XMLHttpRequest();
        xhr.open("POST", url);
        xhr.onreadystatechange = changeFunction
        xhr.send(data);
    },
    outputError: function(error) {
        // Update inner HTML of form error element
        alert(error);
    }
}