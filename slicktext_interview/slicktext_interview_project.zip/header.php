<!DOCTYPE HTML>
<html>
    <head>
        <title>SlickText Interview</title>
        <link rel='stylesheet' type='text/css' href='style.css' />
        <link href="./favicon.ico" rel="icon" type="image/x-icon">
        <script type='text/javascript' src='main.js'></script>
    </head>
    <body>
        <div class='header_back'>
            <img class='main' src='https://www.slicktext.com/images/logos/logo_color_dark.svg' />
            <br />
            <h1>User Management System</h1>
        </div>