<?php
Class DB {
    public static $dbhost = "localhost";
    public static $dbname = "slicktext_interview";
    public static $dbuser = "slicktext";
    public static $dbpass = "slick";
}